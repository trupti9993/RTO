﻿# RTO-Management-System
Create a database rto in phpmyadmin and import rto.sql from database folder.
